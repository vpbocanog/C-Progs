#include<iostream>
using namespace std;
int factorial(int n);
int main()
{c:
    int n;
    cout<<"\n.................\n";
    cout << "|Enter a number:|\n";
     cout<<".................\n";
    cin >> n;
    cout << "Factorial of " << n << " = " << factorial(n);
    goto c;
    return 0;
}
int factorial(int n)
{
    if(n > 1)
        return n * factorial(n - 1);
}
