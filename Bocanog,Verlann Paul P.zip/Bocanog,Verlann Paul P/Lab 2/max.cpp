#include <iostream>
using namespace std;
int max(int x, int y)
{ 

	int ans;
	if (x>y) ans =x;
	else ans =y;
	return ans;
}
int main()
{c:
	int a, b;
		cout<<"\n~~~~~~~~~~~~~~~~~~~~\n";
		cout<<"|Enter two numbers:|\n";
		cout<<"~~~~~~~~~~~~~~~~~~~~\n";
	cin>>a>>b;

	cout<<max(a,b)<<" is greater\n";

	goto c;
	return 0;
	
}


