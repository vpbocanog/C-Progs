#include <iostream>
using namespace std;
int main(){c:
	int numbers[10];
	cout<<"==========================\n";
	cout<<"|Please input 10 numbers:|"<<endl;
	cout<<"==========================\n";
	for (int i = 1; i<=10;i++)
	{
	while(!(cin>> numbers[i])){
		cout<<"Error, try again."<<endl;
		cin.clear();
		cin.sync();
		}	
	}
	
	int HighestNum = -9999999,HighestNum2;
	int LowestNum = numbers[0];
	int LowestNum2 = numbers[0];

	for (int count1 = 1; count1<=10; count1++){
		if(numbers[count1]>HighestNum){
		HighestNum= numbers[count1];
		}
	}
	for (int count2 = 1;count2<=10; count2++){
		if(numbers[count2]>HighestNum2 && numbers[count2]<HighestNum){
		HighestNum2= numbers[count2];	
		}
	}
	
	for(int count3= 1;count3<=10;count3++){
		if(numbers[count3]<LowestNum){
			LowestNum = numbers[count3];
		}
	}
	for(int count4= 1;count4<=10;count4++){
		if(numbers[count4]<LowestNum2 && numbers[count4]>LowestNum){
			LowestNum2 = numbers[count4];
		}
	}
	cout<<"========================================\n";
	cout<<"Highest:"<<HighestNum<<endl;
	cout<<"Second to Highest:"<<HighestNum2<<endl;
	cout<<"Lowest: "<<LowestNum<<endl;
	cout<<"Second to Lowest: "<<LowestNum2<<endl;
	cout<<"========================================\n";
	goto c;
}
