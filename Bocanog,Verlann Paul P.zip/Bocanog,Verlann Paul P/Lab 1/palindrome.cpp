#include <iostream>
#include <string.h>
using namespace std;
int main()
{d:
    char str1[20], str2[20];
    int i, j, len = 0, flag = 0;
    cout<<"=====================\n";
    cout <<"|   Enter a word:   |\n";
    cout<<"=====================\n";
    gets(str1);
    len = strlen(str1) - 1;
    for (i = len, j = 0; i >= 0 ; i--, j++)
        str2[j] = str1[i];
    if (strcmp(str1, str2))
        flag = 1;
    if (flag == 1)
    {
    	cout<<"--------------------------------\n";
        cout << str1 << " is not a palindrome\n";
        cout<<"--------------------------------\n\n";
    }
    else
    {
    	cout<<"----------------------------------\n";
        cout << str1 << " is a palindrome\n";
        cout<<"----------------------------------\n\n";
    }
    goto d;
    return 0;
}
