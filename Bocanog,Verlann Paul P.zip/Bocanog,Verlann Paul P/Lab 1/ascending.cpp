#include <iostream>
using namespace std;
 
int main()
{a:
	
    int arr[100];
    int size, i, j, temp;
 
   	size=10;
 	cout<<"*********************\n";
    cout<<"* Enter 10 numbers: *\n";
    cout<<"*********************\n";
    for(i=0; i<size; i++)
    {
    	while(!(cin>>arr[i]))
	{
		cout<<"Error, try again."<<endl;
		cin.clear();
		cin.sync();
	}
	}
    for(i=0; i<size; i++)
    {
        for(j=i+1; j<size; j++)
        {
            
            if(arr[j] < arr[i])
            {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
    cout<<"**********************************\n";
    cout<<"* Your input in ascending order: *"<<endl;
    cout<<"**********************************\n";
    for(i=0; i<size; i++)
    {
        cout<<arr[i]<<endl;
    }
 	goto a;
    return 0;
}
 


