#include <iostream>  
using namespace std;  
int main()  
{  b:
int a[10], n, i;   
cout<<"\n\noooooooooooooooooooooooooooooooooooooooooo\n" ;
cout<<"o     Enter the number to convert:       o\n";  
cout<<"oooooooooooooooooooooooooooooooooooooooooo\n";    
  while(!(cin>>n))
	{
		cout<<"Error, try again."<<endl;
		cin.clear();
		cin.sync();
	}
for(i=0; n>0; i++)    
{    
a[i]=n%2;    
n= n/2;  
}   

cout<<"Binary of the given number= ";

for(i=i-1 ;i>=0 ;i--)    
{    
cout<<a[i];    
}    
goto b;

}  
